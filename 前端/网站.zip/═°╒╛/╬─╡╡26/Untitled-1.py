import pandas as pd
import sqlite3
from pathlib import Path

# 路径设置
excel_path = Path(r'D:\openai\df.xlsx')
db_path = Path(r'D:\openai\df.db')
table_name = 'df'  # 可自定义

# 读取 Excel 文件
df = pd.read_excel(excel_path, sheet_name=0)  # 只读取第一个 sheet，你也可以指定名字或遍历所有

# 打印列名（可选）
print("📋 检测到的列名：", df.columns.tolist())

# 连接 SQLite 数据库
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# 如果表已存在，先删除
cursor.execute(f"DROP TABLE IF EXISTS {table_name}")

# 将 DataFrame 写入数据库（自动创建表）
df.to_sql(table_name, conn, index=False)

# 关闭连接
conn.commit()
conn.close()

print(f"✅ 数据已成功写入数据库 {db_path.name}，表名为：{table_name}")
