# -*- coding: utf-8 -*-
"""
读取 D:\openai\函数完整名称.txt（每行一个全名），
为每个函数收集：模块/路径/类/基类/描述/函数类型/装饰器/源码/参数签名等，
写入 SQLite（D:\openai\函数信息表.db，表：函数元信息）和 Excel（D:\openai\函数信息表.xlsx）。

作者：你的 20 年“函数文档专家”🙂
"""

import sys
import os
import sqlite3
import inspect
import importlib
from pathlib import Path
from typing import Any, List, Dict, Optional, Tuple

import pandas as pd

# ============ 路径与常量 ============

BASE_DIR = Path("D:/openai")
BASE_DIR.mkdir(parents=True, exist_ok=True)

LIST_FILE = BASE_DIR / "函数完整名称.txt"    # 输入：每行一个全名
DB_PATH   = BASE_DIR / "函数信息表.db"       # 输出：SQLite
XLSX_PATH = BASE_DIR / "函数信息表.xlsx"     # 输出：Excel
LOG_PATH  = BASE_DIR / "build_func_meta.log"

TABLE_NAME = "函数元信息"

# 中文字段顺序（与 Excel/DB 一致，逐参数写一行）
COLUMNS = [
    "模块名称", "模块路径",
    "类名称", "类完整名", "类基类", "类描述",
    "函数名称", "函数完整名称", "所属模块", "所属类",
    "函数类型", "装饰器", "函数描述", "源码定义",
    "是否有默认值",
    "参数名称", "参数类型", "参数是否有默认值", "参数默认值", "参数描述"
]

# ============ 工具函数 ============

def log(msg: str) -> None:
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(msg.rstrip() + "\n")

def import_by_prefix(tokens: List[str]) -> Tuple[Any, int]:
    """
    尝试从左到右找到“可导入的最长模块前缀”，返回(对象/模块, 使用的token数)
    例如：['pandas','core','frame','DataFrame','abs'] -> import pandas.core.frame 成功
          返回(module=pandas.core.frame, used=3)，后续 getattr 链接 DataFrame.abs
    """
    for i in range(len(tokens), 0, -1):
        mod_name = ".".join(tokens[:i])
        try:
            mod = importlib.import_module(mod_name)
            return mod, i
        except Exception:
            continue
    # 至少尝试最左 token
    raise ImportError(f"无法导入任何模块前缀：{'.'.join(tokens)}")

def resolve_dotted(fullname: str) -> Any:
    """
    解析全名为对象。例如：
    pandas.core.frame.DataFrame.abs
    """
    tokens = fullname.split(".")
    mod, used = import_by_prefix(tokens)
    obj: Any = mod
    for tok in tokens[used:]:
        obj = getattr(obj, tok)
    return obj

def safe_get_module_path(obj: Any) -> Optional[str]:
    try:
        p = inspect.getsourcefile(obj) or inspect.getfile(obj)
        return str(Path(p).resolve())
    except Exception:
        return None

def get_owner_class_and_attr(fullname: str) -> Tuple[Optional[type], Optional[str]]:
    """
    推断“所属类”和“函数名”（最后一个 token）：
    - 若倒数第二个对象是类，则所属类=该类，函数名=最后 token
    - 否则所属类=None，函数名=最后 token
    """
    tokens = fullname.split(".")
    if len(tokens) < 2:
        return None, tokens[-1]
    # 先解析“倒数第二层对象”
    try:
        parent_obj = resolve_dotted(".".join(tokens[:-1]))
        func_name = tokens[-1]
        if inspect.isclass(parent_obj):
            return parent_obj, func_name
    except Exception:
        pass
    return None, tokens[-1]

def detect_decorator_and_type(owner_cls: Optional[type], func_attr_name: str, obj: Any) -> Tuple[str, str]:
    """
    判定装饰器与函数类型（中文）：
    - 静态方法：@staticmethod / "静态方法"
    - 类方法：@classmethod / "类方法"
    - 实例方法：普通 def 定义在类里 / "实例方法"
    - 模块函数：定义在模块层 / "模块函数"
    - 方法描述符/内置方法：inspect.ismethoddescriptor / builtin
    """
    decorators = []
    func_type = "实例方法"  # 默认

    # 先粗分：如果没有所属类 -> 模块函数/内置
    if owner_cls is None:
        # 模块对象：可能是函数 or 内置函数/方法
        if inspect.isbuiltin(obj):
            func_type = "内置函数/方法"
        elif inspect.isfunction(obj):
            func_type = "模块函数"
        elif inspect.ismethoddescriptor(obj):
            func_type = "方法描述符"
        else:
            # Fallback
            func_type = type(obj).__name__
        return ",".join(decorators), func_type

    # 类内定义：尝试静态、类方法判定（用 getattr_static 保证拿到“原值”）
    try:
        raw = inspect.getattr_static(owner_cls, func_attr_name)
        if isinstance(raw, staticmethod):
            decorators.append("@staticmethod")
            func_type = "静态方法"
        elif isinstance(raw, classmethod):
            decorators.append("@classmethod")
            func_type = "类方法"
        elif isinstance(raw, property):
            decorators.append("@property")
            func_type = "属性/描述符"
        else:
            # 普通绑定函数、方法描述符
            if inspect.ismethoddescriptor(raw):
                func_type = "方法描述符"
            else:
                func_type = "实例方法"
    except Exception:
        # 若无法静态获取，退化基于 obj
        if inspect.isbuiltin(obj):
            func_type = "内置函数/方法"
        elif inspect.ismethoddescriptor(obj):
            func_type = "方法描述符"
        elif inspect.isfunction(obj):
            func_type = "实例方法"
        else:
            func_type = type(obj).__name__

    return ",".join(decorators), func_type

def text_or_none(s: Optional[str]) -> Optional[str]:
    if s is None:
        return None
    s = str(s).strip()
    return s if s else None

def get_class_bases_text(cls: type) -> str:
    try:
        bases = [b.__name__ for b in getattr(cls, "__bases__", [])]
        return ",".join(bases)
    except Exception:
        return ""

def get_signature_safe(obj: Any) -> Optional[inspect.Signature]:
    try:
        return inspect.signature(obj)
    except Exception:
        return None

def get_source_safe(obj: Any) -> Optional[str]:
    try:
        return inspect.getsource(obj)
    except Exception:
        return None

def annotation_to_str(ann: Any) -> Optional[str]:
    if ann is inspect._empty:
        return None
    try:
        return str(ann)
    except Exception:
        return None

def default_to_str(d: Any) -> Optional[str]:
    if d is inspect._empty:
        return None
    try:
        return repr(d)
    except Exception:
        try:
            return str(d)
        except Exception:
            return None

def row_dict_template() -> Dict[str, Any]:
    return {k: None for k in COLUMNS}

def build_rows_for_fullname(fullname: str) -> List[Dict[str, Any]]:
    """
    根据“函数完整名称”生成“逐参数行”。若函数0参数，也生成一行（参数字段为空）。
    """
    rows: List[Dict[str, Any]] = []
    try:
        obj = resolve_dotted(fullname)
    except Exception as e:
        log(f"[NOT FOUND] {fullname} | {e}")
        return rows

    owner_cls, func_name = get_owner_class_and_attr(fullname)

    # 模块与路径（优先取函数的模块与路径，若不可取再从类/模块取）
    module_name = getattr(obj, "__module__", None)
    module_path = safe_get_module_path(obj)

    # 类相关字段
    class_name = class_fullname = class_bases = class_doc = None
    if owner_cls is not None:
        class_name = getattr(owner_cls, "__name__", None)
        class_fullname = f"{owner_cls.__module__}.{owner_cls.__name__}"
        class_bases = get_class_bases_text(owner_cls)
        class_doc = text_or_none(getattr(owner_cls, "__doc__", None))
        # 若函数本身无法获取模块信息，尝试用类的信息补齐
        if module_name is None:
            module_name = getattr(owner_cls, "__module__", None)
        if module_path is None:
            module_path = safe_get_module_path(owner_cls)

    # 函数描述/源码/装饰器/类型
    func_doc = text_or_none(getattr(obj, "__doc__", None))
    func_source = get_source_safe(obj)
    decorators, func_type = detect_decorator_and_type(owner_cls, func_name, obj)

    # 签名与参数
    sig = get_signature_safe(obj)
    has_any_default = False

    if sig is None or len(sig.parameters) == 0:
        # 无可取签名或0参数：也入一行（参数字段留空）
        rd = row_dict_template()
        rd.update({
            "模块名称": module_name,
            "模块路径": module_path,
            "类名称": class_name,
            "类完整名": class_fullname,
            "类基类": class_bases,
            "类描述": class_doc,

            "函数名称": func_name,
            "函数完整名称": fullname,
            "所属模块": module_name,
            "所属类": class_name,

            "函数类型": func_type,
            "装饰器": decorators,
            "函数描述": func_doc,
            "源码定义": func_source,

            "是否有默认值": 1 if has_any_default else 0,

            "参数名称": None,
            "参数类型": None,
            "参数是否有默认值": None,
            "参数默认值": None,
            "参数描述": None,
        })
        rows.append(rd)
        return rows

    # 有签名：逐参数入库
    for p in sig.parameters.values():
        p_name = p.name
        p_ann = annotation_to_str(p.annotation)
        p_def = default_to_str(p.default)
        p_has_def = 0
        if p.default is not inspect._empty:
            p_has_def = 1
            has_any_default = True

        rd = row_dict_template()
        rd.update({
            "模块名称": module_name,
            "模块路径": module_path,
            "类名称": class_name,
            "类完整名": class_fullname,
            "类基类": class_bases,
            "类描述": class_doc,

            "函数名称": func_name,
            "函数完整名称": fullname,
            "所属模块": module_name,
            "所属类": class_name,

            "函数类型": func_type,
            "装饰器": decorators,
            "函数描述": func_doc,
            "源码定义": func_source,

            "是否有默认值": None,  # 先留空，函数级“是否有默认值”稍后批量回填
            "参数名称": p_name,
            "参数类型": p_ann,
            "参数是否有默认值": p_has_def,
            "参数默认值": p_def,
            "参数描述": None,
        })
        rows.append(rd)

    # 回填该函数级“是否有默认值”
    for rd in rows:
        rd["是否有默认值"] = 1 if has_any_default else 0

    return rows

def ensure_table(conn: sqlite3.Connection) -> None:
    sql = f"""
    CREATE TABLE IF NOT EXISTS {TABLE_NAME} (
        编号 INTEGER PRIMARY KEY AUTOINCREMENT,
        模块名称 TEXT,
        模块路径 TEXT,
        类名称 TEXT,
        类完整名 TEXT,
        类基类 TEXT,
        类描述 TEXT,
        函数名称 TEXT,
        函数完整名称 TEXT,
        所属模块 TEXT,
        所属类 TEXT,
        函数类型 TEXT,
        装饰器 TEXT,
        函数描述 TEXT,
        源码定义 TEXT,
        是否有默认值 BOOLEAN,
        参数名称 TEXT,
        参数类型 TEXT,
        参数是否有默认值 BOOLEAN,
        参数默认值 TEXT,
        参数描述 TEXT
    );
    """
    conn.execute(sql)
    conn.commit()

def insert_rows(conn: sqlite3.Connection, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        return
    placeholders = ",".join(["?"] * len(COLUMNS))
    sql = f"INSERT INTO {TABLE_NAME} ({','.join(COLUMNS)}) VALUES ({placeholders})"
    values = [[r.get(k) for k in COLUMNS] for r in rows]
    conn.executemany(sql, values)
    conn.commit()

def load_fullnames_from_file(path: Path) -> List[str]:
    if not path.exists():
        raise FileNotFoundError(f"未找到函数清单文件：{path}\n请创建该文件，并将每个函数完整名称放在单独一行。")
    lines = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            s = line.strip()
            if s and not s.startswith("#"):
                lines.append(s)
    return lines

def main():
    # 清理上次日志
    if LOG_PATH.exists():
        LOG_PATH.unlink(missing_ok=True)

    try:
        fullnames = load_fullnames_from_file(LIST_FILE)
    except Exception as e:
        print(str(e))
        print("\n示例：文件内容形如：\n  pandas.core.frame.DataFrame.abs\n  pandas.core.frame.DataFrame.apply\n  ...")
        sys.exit(1)

    print(f"读取到 {len(fullnames)} 个函数名称，开始采集...（详细错误见：{LOG_PATH}）")

    all_rows: List[Dict[str, Any]] = []
    ok_funcs = 0

    for fn in fullnames:
        try:
            rows = build_rows_for_fullname(fn)
            if rows:
                all_rows.extend(rows)
                ok_funcs += 1
            else:
                log(f"[NO ROWS] {fn}")
        except Exception as e:
            log(f"[FAIL] {fn} | {e}")

    # 写入 SQLite
    conn = sqlite3.connect(DB_PATH)
    ensure_table(conn)
    insert_rows(conn, all_rows)
    conn.close()

    # 写入 Excel
    df = pd.DataFrame(all_rows, columns=COLUMNS)
    df.to_excel(XLSX_PATH, index=False)

    print(f"✅ 采集完成：成功解析 {ok_funcs}/{len(fullnames)} 个函数。")
    print(f"📦 SQLite：{DB_PATH}  表：{TABLE_NAME}（{len(all_rows)} 行）")
    print(f"📊 Excel：{XLSX_PATH}")
    if LOG_PATH.exists():
        print(f"📝 日志：{LOG_PATH}（包含解析失败或缺失信息项）")

if __name__ == "__main__":
    # 可选：确保 pandas 可用
    try:
        import pandas  # noqa
    except Exception:
        print("⚠️ 未安装 pandas，无法解析 pandas 的对象。\n请先安装：pip install pandas")
        # 不中断，允许解析其他库的函数（若你清单里有）
    main()
