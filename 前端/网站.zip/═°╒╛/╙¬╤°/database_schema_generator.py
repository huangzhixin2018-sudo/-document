#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Python函数查询系统数据库表结构生成器
根据HTML文件中的数据结构生成数据库表结构和XLSX文件
"""

import pandas as pd
import sqlite3
from datetime import datetime
import json

class DatabaseSchemaGenerator:
    def __init__(self):
        self.tables = {}
        
    def generate_function_query_schema(self):
        """生成函数查询系统的数据库表结构"""
        
        # 1. 函数基本信息表
        functions_table = {
            'table_name': 'functions',
            'columns': [
                {'name': 'id', 'type': 'INTEGER', 'constraints': 'PRIMARY KEY AUTOINCREMENT'},
                {'name': 'qualified_name', 'type': 'VARCHAR(255)', 'constraints': 'UNIQUE NOT NULL'},
                {'name': 'function_name', 'type': 'VARCHAR(100)', 'constraints': 'NOT NULL'},
                {'name': 'module_name', 'type': 'VARCHAR(100)', 'constraints': 'NOT NULL'},
                {'name': 'description', 'type': 'TEXT', 'constraints': ''},
                {'name': 'function_type', 'type': 'VARCHAR(50)', 'constraints': 'NOT NULL'},  # 函数/方法
                {'name': 'source_definition', 'type': 'TEXT', 'constraints': ''},
                {'name': 'return_value_description', 'type': 'TEXT', 'constraints': ''},
                {'name': 'created_at', 'type': 'TIMESTAMP', 'constraints': 'DEFAULT CURRENT_TIMESTAMP'},
                {'name': 'updated_at', 'type': 'TIMESTAMP', 'constraints': 'DEFAULT CURRENT_TIMESTAMP'}
            ]
        }
        
        # 2. 函数参数表
        parameters_table = {
            'table_name': 'function_parameters',
            'columns': [
                {'name': 'id', 'type': 'INTEGER', 'constraints': 'PRIMARY KEY AUTOINCREMENT'},
                {'name': 'function_id', 'type': 'INTEGER', 'constraints': 'NOT NULL'},
                {'name': 'parameter_name', 'type': 'VARCHAR(100)', 'constraints': 'NOT NULL'},
                {'name': 'parameter_type', 'type': 'VARCHAR(100)', 'constraints': 'NOT NULL'},
                {'name': 'structure_type', 'type': 'VARCHAR(50)', 'constraints': 'NOT NULL'},  # 基础类型/可变参数等
                {'name': 'has_default_value', 'type': 'BOOLEAN', 'constraints': 'DEFAULT FALSE'},
                {'name': 'default_value', 'type': 'TEXT', 'constraints': ''},
                {'name': 'is_required', 'type': 'BOOLEAN', 'constraints': 'DEFAULT TRUE'},
                {'name': 'description', 'type': 'TEXT', 'constraints': ''},
                {'name': 'parameter_order', 'type': 'INTEGER', 'constraints': 'NOT NULL'},
                {'name': 'created_at', 'type': 'TIMESTAMP', 'constraints': 'DEFAULT CURRENT_TIMESTAMP'},
                {'name': 'FOREIGN KEY(function_id)', 'type': '', 'constraints': 'REFERENCES functions(id) ON DELETE CASCADE'}
            ]
        }
        
        # 3. 模块信息表
        modules_table = {
            'table_name': 'modules',
            'columns': [
                {'name': 'id', 'type': 'INTEGER', 'constraints': 'PRIMARY KEY AUTOINCREMENT'},
                {'name': 'module_name', 'type': 'VARCHAR(100)', 'constraints': 'UNIQUE NOT NULL'},
                {'name': 'description', 'type': 'TEXT', 'constraints': ''},
                {'name': 'library_name', 'type': 'VARCHAR(100)', 'constraints': 'NOT NULL'},  # builtin/pandas/numpy等
                {'name': 'created_at', 'type': 'TIMESTAMP', 'constraints': 'DEFAULT CURRENT_TIMESTAMP'}
            ]
        }
        
        # 4. 使用示例表
        examples_table = {
            'table_name': 'function_examples',
            'columns': [
                {'name': 'id', 'type': 'INTEGER', 'constraints': 'PRIMARY KEY AUTOINCREMENT'},
                {'name': 'function_id', 'type': 'INTEGER', 'constraints': 'NOT NULL'},
                {'name': 'example_title', 'type': 'VARCHAR(255)', 'constraints': 'NOT NULL'},
                {'name': 'example_code', 'type': 'TEXT', 'constraints': 'NOT NULL'},
                {'name': 'example_output', 'type': 'TEXT', 'constraints': ''},
                {'name': 'example_description', 'type': 'TEXT', 'constraints': ''},
                {'name': 'difficulty_level', 'type': 'VARCHAR(20)', 'constraints': 'DEFAULT "beginner"'},  # beginner/intermediate/advanced
                {'name': 'created_at', 'type': 'TIMESTAMP', 'constraints': 'DEFAULT CURRENT_TIMESTAMP'},
                {'name': 'FOREIGN KEY(function_id)', 'type': '', 'constraints': 'REFERENCES functions(id) ON DELETE CASCADE'}
            ]
        }
        
        self.tables['function_query'] = {
            'functions': functions_table,
            'function_parameters': parameters_table,
            'modules': modules_table,
            'function_examples': examples_table
        }
        
    def generate_function_library_schema(self):
        """生成函数库系统的数据库表结构"""
        
        # 1. 库信息表
        libraries_table = {
            'table_name': 'libraries',
            'columns': [
                {'name': 'id', 'type': 'INTEGER', 'constraints': 'PRIMARY KEY AUTOINCREMENT'},
                {'name': 'library_name', 'type': 'VARCHAR(100)', 'constraints': 'UNIQUE NOT NULL'},
                {'name': 'display_name', 'type': 'VARCHAR(255)', 'constraints': 'NOT NULL'},
                {'name': 'description', 'type': 'TEXT', 'constraints': ''},
                {'name': 'version', 'type': 'VARCHAR(50)', 'constraints': ''},
                {'name': 'created_at', 'type': 'TIMESTAMP', 'constraints': 'DEFAULT CURRENT_TIMESTAMP'}
            ]
        }
        
        # 2. 模块信息表
        modules_table = {
            'table_name': 'library_modules',
            'columns': [
                {'name': 'id', 'type': 'INTEGER', 'constraints': 'PRIMARY KEY AUTOINCREMENT'},
                {'name': 'library_id', 'type': 'INTEGER', 'constraints': 'NOT NULL'},
                {'name': 'module_name', 'type': 'VARCHAR(100)', 'constraints': 'NOT NULL'},
                {'name': 'description', 'type': 'TEXT', 'constraints': ''},
                {'name': 'created_at', 'type': 'TIMESTAMP', 'constraints': 'DEFAULT CURRENT_TIMESTAMP'},
                {'name': 'FOREIGN KEY(library_id)', 'type': '', 'constraints': 'REFERENCES libraries(id) ON DELETE CASCADE'}
            ]
        }
        
        # 3. 类信息表
        classes_table = {
            'table_name': 'classes',
            'columns': [
                {'name': 'id', 'type': 'INTEGER', 'constraints': 'PRIMARY KEY AUTOINCREMENT'},
                {'name': 'module_id', 'type': 'INTEGER', 'constraints': 'NOT NULL'},
                {'name': 'class_name', 'type': 'VARCHAR(255)', 'constraints': 'NOT NULL'},
                {'name': 'semantic_description', 'type': 'TEXT', 'constraints': ''},
                {'name': 'created_at', 'type': 'TIMESTAMP', 'constraints': 'DEFAULT CURRENT_TIMESTAMP'},
                {'name': 'FOREIGN KEY(module_id)', 'type': '', 'constraints': 'REFERENCES library_modules(id) ON DELETE CASCADE'}
            ]
        }
        
        # 4. 函数/方法/属性表
        items_table = {
            'table_name': 'library_items',
            'columns': [
                {'name': 'id', 'type': 'INTEGER', 'constraints': 'PRIMARY KEY AUTOINCREMENT'},
                {'name': 'module_id', 'type': 'INTEGER', 'constraints': 'NOT NULL'},
                {'name': 'class_id', 'type': 'INTEGER', 'constraints': ''},  # 如果是类的方法/属性
                {'name': 'item_name', 'type': 'VARCHAR(255)', 'constraints': 'NOT NULL'},
                {'name': 'item_type', 'type': 'VARCHAR(50)', 'constraints': 'NOT NULL'},  # function/method/attribute
                {'name': 'semantic_description', 'type': 'TEXT', 'constraints': ''},
                {'name': 'operation_type', 'type': 'VARCHAR(50)', 'constraints': 'NOT NULL'},  # 构造/复制/访问/查询等
                {'name': 'input_structure', 'type': 'TEXT', 'constraints': ''},
                {'name': 'output_structure', 'type': 'TEXT', 'constraints': ''},
                {'name': 'created_at', 'type': 'TIMESTAMP', 'constraints': 'DEFAULT CURRENT_TIMESTAMP'},
                {'name': 'FOREIGN KEY(module_id)', 'type': '', 'constraints': 'REFERENCES library_modules(id) ON DELETE CASCADE'},
                {'name': 'FOREIGN KEY(class_id)', 'type': '', 'constraints': 'REFERENCES classes(id) ON DELETE SET NULL'}
            ]
        }
        
        # 5. 操作类型表
        operation_types_table = {
            'table_name': 'operation_types',
            'columns': [
                {'name': 'id', 'type': 'INTEGER', 'constraints': 'PRIMARY KEY AUTOINCREMENT'},
                {'name': 'operation_name', 'type': 'VARCHAR(50)', 'constraints': 'UNIQUE NOT NULL'},
                {'name': 'description', 'type': 'TEXT', 'constraints': ''},
                {'name': 'category', 'type': 'VARCHAR(50)', 'constraints': ''},  # 数据操作/控制流/IO等
                {'name': 'created_at', 'type': 'TIMESTAMP', 'constraints': 'DEFAULT CURRENT_TIMESTAMP'}
            ]
        }
        
        self.tables['function_library'] = {
            'libraries': libraries_table,
            'library_modules': modules_table,
            'classes': classes_table,
            'library_items': items_table,
            'operation_types': operation_types_table
        }
    
    def generate_sample_data(self):
        """生成示例数据"""
        
        # 函数查询系统示例数据
        function_query_data = {
            'functions': [
                {
                    'qualified_name': 'os.path.join',
                    'function_name': 'join',
                    'module_name': 'os.path',
                    'description': '将多个路径组合成一个完整路径',
                    'function_type': '函数',
                    'source_definition': 'def join(path, *paths): ...',
                    'return_value_description': '返回组合后的路径字符串'
                },
                {
                    'qualified_name': 'str.split',
                    'function_name': 'split',
                    'module_name': 'str',
                    'description': '通过指定分隔符对字符串进行分割',
                    'function_type': '方法',
                    'source_definition': 'def split(self, sep=None, maxsplit=-1): ...',
                    'return_value_description': '返回分割后的字符串列表'
                },
                {
                    'qualified_name': 'pandas.DataFrame.head',
                    'function_name': 'head',
                    'module_name': 'pandas.DataFrame',
                    'description': '返回DataFrame的前n行数据',
                    'function_type': '方法',
                    'source_definition': 'def head(self, n=5): ...',
                    'return_value_description': '返回包含前n行的DataFrame'
                }
            ],
            'function_parameters': [
                {
                    'function_qualified_name': 'os.path.join',
                    'parameter_name': 'path',
                    'parameter_type': 'str',
                    'structure_type': '基础类型',
                    'has_default_value': False,
                    'default_value': '',
                    'is_required': True,
                    'description': '第一个路径组件',
                    'parameter_order': 1
                },
                {
                    'function_qualified_name': 'os.path.join',
                    'parameter_name': 'paths',
                    'parameter_type': 'str',
                    'structure_type': '可变参数',
                    'has_default_value': False,
                    'default_value': '',
                    'is_required': False,
                    'description': '额外的路径组件',
                    'parameter_order': 2
                },
                {
                    'function_qualified_name': 'str.split',
                    'parameter_name': 'sep',
                    'parameter_type': 'str',
                    'structure_type': '基础类型',
                    'has_default_value': True,
                    'default_value': 'None',
                    'is_required': False,
                    'description': '分隔符，默认为所有空白字符',
                    'parameter_order': 1
                },
                {
                    'function_qualified_name': 'str.split',
                    'parameter_name': 'maxsplit',
                    'parameter_type': 'int',
                    'structure_type': '基础类型',
                    'has_default_value': True,
                    'default_value': '-1',
                    'is_required': False,
                    'description': '最大分割次数',
                    'parameter_order': 2
                }
            ],
            'modules': [
                {
                    'module_name': 'os.path',
                    'description': '操作系统路径操作模块',
                    'library_name': 'builtin'
                },
                {
                    'module_name': 'str',
                    'description': '字符串操作方法',
                    'library_name': 'builtin'
                },
                {
                    'module_name': 'pandas.DataFrame',
                    'description': 'Pandas DataFrame类',
                    'library_name': 'pandas'
                }
            ],
            'function_examples': [
                {
                    'function_qualified_name': 'os.path.join',
                    'example_title': '基本路径拼接',
                    'example_code': "import os\npath = os.path.join('home', 'user', 'documents')\nprint(path)",
                    'example_output': "home/user/documents",
                    'example_description': '演示如何使用join函数拼接路径组件',
                    'difficulty_level': 'beginner'
                },
                {
                    'function_qualified_name': 'str.split',
                    'example_title': '字符串分割',
                    'example_code': "text = 'apple,banana,orange'\nfruits = text.split(',')\nprint(fruits)",
                    'example_output': "['apple', 'banana', 'orange']",
                    'example_description': '使用逗号分割字符串',
                    'difficulty_level': 'beginner'
                }
            ]
        }
        
        # 函数库系统示例数据
        function_library_data = {
            'libraries': [
                {
                    'library_name': 'builtin',
                    'display_name': 'Python 内置库',
                    'description': 'Python标准库中的内置模块和函数',
                    'version': '3.11'
                },
                {
                    'library_name': 'pandas',
                    'display_name': 'Pandas 库',
                    'description': '数据分析和操作库',
                    'version': '2.0.0'
                },
                {
                    'library_name': 'numpy',
                    'display_name': 'NumPy 库',
                    'description': '数值计算库',
                    'version': '1.24.0'
                }
            ],
            'library_modules': [
                {
                    'library_name': 'builtin',
                    'module_name': 'os',
                    'description': '操作系统接口'
                },
                {
                    'library_name': 'builtin',
                    'module_name': 'sys',
                    'description': '系统相关参数和函数'
                },
                {
                    'library_name': 'pandas',
                    'module_name': 'pandas',
                    'description': '主要数据结构'
                }
            ],
            'classes': [
                {
                    'module_name': 'os',
                    'class_name': 'os.PathLike',
                    'semantic_description': '抽象基类，表示文件系统路径的对象'
                },
                {
                    'module_name': 'pandas',
                    'class_name': 'pandas.DataFrame',
                    'semantic_description': '二维标签数据结构，类似电子表格'
                }
            ],
            'library_items': [
                {
                    'module_name': 'os',
                    'class_name': 'os.PathLike',
                    'item_name': '__fspath__()',
                    'item_type': 'method',
                    'semantic_description': '返回文件系统路径的字符串表示',
                    'operation_type': '转换',
                    'input_structure': 'PathLike对象',
                    'output_structure': '字符串路径'
                },
                {
                    'module_name': 'os',
                    'class_name': '',
                    'item_name': 'os.listdir(path)',
                    'item_type': 'function',
                    'semantic_description': '返回指定路径下的文件和目录列表',
                    'operation_type': '查询',
                    'input_structure': '目录路径',
                    'output_structure': '文件名列表'
                },
                {
                    'module_name': 'pandas',
                    'class_name': 'pandas.DataFrame',
                    'item_name': 'head([n])',
                    'item_type': 'method',
                    'semantic_description': '返回前n行数据',
                    'operation_type': '查询',
                    'input_structure': 'DataFrame',
                    'output_structure': 'DataFrame子集'
                }
            ],
            'operation_types': [
                {'operation_name': '构造', 'description': '创建新对象或实例', 'category': '对象操作'},
                {'operation_name': '复制', 'description': '复制现有对象', 'category': '对象操作'},
                {'operation_name': '访问', 'description': '获取对象属性或值', 'category': '数据访问'},
                {'operation_name': '查询', 'description': '查找或检索数据', 'category': '数据操作'},
                {'operation_name': '设置', 'description': '修改对象属性或值', 'category': '数据操作'},
                {'operation_name': '插入', 'description': '在数据结构中添加元素', 'category': '数据操作'},
                {'operation_name': '删除', 'description': '移除数据结构中的元素', 'category': '数据操作'},
                {'operation_name': '计算', 'description': '执行数学或逻辑运算', 'category': '计算操作'},
                {'operation_name': '转换', 'description': '将数据从一种格式转换为另一种', 'category': '数据转换'},
                {'operation_name': '聚合', 'description': '将多个值合并为单个值', 'category': '数据操作'},
                {'operation_name': '排序', 'description': '对数据进行排序', 'category': '数据操作'},
                {'operation_name': '重组', 'description': '重新组织数据结构', 'category': '数据操作'},
                {'operation_name': '判断', 'description': '返回布尔值的条件检查', 'category': '逻辑操作'},
                {'operation_name': '输入', 'description': '从外部源读取数据', 'category': 'IO操作'},
                {'operation_name': '输出', 'description': '将数据写入外部目标', 'category': 'IO操作'},
                {'operation_name': '迭代', 'description': '遍历数据结构', 'category': '控制流'},
                {'operation_name': '选择', 'description': '从数据集中选择特定元素', 'category': '数据操作'}
            ]
        }
        
        return {
            'function_query': function_query_data,
            'function_library': function_library_data
        }
    
    def create_sql_scripts(self):
        """生成SQL创建脚本"""
        sql_scripts = {}
        
        for system_name, tables in self.tables.items():
            sql_scripts[system_name] = []
            
            for table_name, table_info in tables.items():
                sql = f"CREATE TABLE {table_name} (\n"
                columns = []
                
                for column in table_info['columns']:
                    if column['name'].startswith('FOREIGN KEY'):
                        columns.append(f"    {column['name']} {column['constraints']}")
                    else:
                        column_def = f"    {column['name']} {column['type']}"
                        if column['constraints']:
                            column_def += f" {column['constraints']}"
                        columns.append(column_def)
                
                sql += ",\n".join(columns)
                sql += "\n);"
                
                sql_scripts[system_name].append(sql)
        
        return sql_scripts
    
    def create_xlsx_schema(self, filename='database_schema.xlsx'):
        """创建XLSX格式的数据库表结构"""
        
        with pd.ExcelWriter(filename, engine='openpyxl') as writer:
            
            # 为每个系统创建工作表
            for system_name, tables in self.tables.items():
                # 创建表结构概览
                overview_data = []
                for table_name, table_info in tables.items():
                    overview_data.append({
                        '表名': table_name,
                        '描述': f'{system_name}系统的{table_name}表',
                        '字段数量': len(table_info['columns']),
                        '主键': next((col['name'] for col in table_info['columns'] if 'PRIMARY KEY' in col['constraints']), '无'),
                        '外键数量': len([col for col in table_info['columns'] if col['name'].startswith('FOREIGN KEY')])
                    })
                
                overview_df = pd.DataFrame(overview_data)
                overview_df.to_excel(writer, sheet_name=f'{system_name}_概览', index=False)
                
                # 为每个表创建详细结构工作表
                for table_name, table_info in tables.items():
                    columns_data = []
                    for col in table_info['columns']:
                        if not col['name'].startswith('FOREIGN KEY'):
                            columns_data.append({
                                '字段名': col['name'],
                                '数据类型': col['type'],
                                '约束条件': col['constraints'],
                                '说明': self.get_column_description(col['name'], table_name)
                            })
                    
                    columns_df = pd.DataFrame(columns_data)
                    sheet_name = f'{system_name}_{table_name}'[:31]  # Excel工作表名限制31字符
                    columns_df.to_excel(writer, sheet_name=sheet_name, index=False)
                
                # 创建示例数据工作表
                sample_data = self.generate_sample_data()
                if system_name in sample_data:
                    for table_name, data in sample_data[system_name].items():
                        if data:  # 确保有数据
                            df = pd.DataFrame(data)
                            sheet_name = f'{system_name}_{table_name}_示例'[:31]
                            df.to_excel(writer, sheet_name=sheet_name, index=False)
        
        print(f"数据库表结构已保存到 {filename}")
    
    def get_column_description(self, column_name, table_name):
        """获取字段描述"""
        descriptions = {
            'id': '主键ID，自动递增',
            'created_at': '创建时间',
            'updated_at': '更新时间',
            'qualified_name': '函数的完整限定名（如os.path.join）',
            'function_name': '函数名称（如join）',
            'module_name': '所属模块名称',
            'description': '功能描述',
            'function_type': '函数类型（函数/方法）',
            'source_definition': '源码定义',
            'return_value_description': '返回值说明',
            'parameter_name': '参数名称',
            'parameter_type': '参数类型',
            'structure_type': '结构类型（基础类型/可变参数等）',
            'has_default_value': '是否有默认值',
            'default_value': '默认值',
            'is_required': '是否必填',
            'parameter_order': '参数顺序',
            'example_title': '示例标题',
            'example_code': '示例代码',
            'example_output': '示例输出',
            'example_description': '示例描述',
            'difficulty_level': '难度级别',
            'library_name': '库名称',
            'display_name': '显示名称',
            'version': '版本号',
            'class_name': '类名',
            'semantic_description': '语义描述',
            'item_name': '项目名称',
            'item_type': '项目类型（function/method/attribute）',
            'operation_type': '操作类型',
            'input_structure': '输入数据结构',
            'output_structure': '输出数据结构',
            'operation_name': '操作名称',
            'category': '分类'
        }
        
        return descriptions.get(column_name, '')
    
    def create_database(self, db_name='python_functions.db'):
        """创建SQLite数据库"""
        conn = sqlite3.connect(db_name)
        
        # 创建表
        sql_scripts = self.create_sql_scripts()
        for system_name, scripts in sql_scripts.items():
            for script in scripts:
                conn.execute(script)
        
        # 插入示例数据
        sample_data = self.generate_sample_data()
        
        # 这里可以添加数据插入逻辑
        # 为了简化，这里只创建表结构
        
        conn.commit()
        conn.close()
        
        print(f"数据库 {db_name} 创建完成")

def main():
    """主函数"""
    generator = DatabaseSchemaGenerator()
    
    # 生成表结构
    generator.generate_function_query_schema()
    generator.generate_function_library_schema()
    
    # 创建XLSX文件
    generator.create_xlsx_schema()
    
    # 创建SQLite数据库
    generator.create_database()
    
    # 打印SQL脚本
    sql_scripts = generator.create_sql_scripts()
    print("\n=== SQL创建脚本 ===")
    for system_name, scripts in sql_scripts.items():
        print(f"\n--- {system_name} 系统 ---")
        for script in scripts:
            print(script)
            print()

if __name__ == "__main__":
    main()
