from flask import Flask, jsonify
import sqlite3

app = Flask(__name__)

# 数据库路径
DATABASE = 'functions.db'

# 获取数据库连接
def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row  # 支持字典风格访问
    return conn

# 测试接口：列出所有函数名称
@app.route('/api/functions', methods=['GET'])
def list_functions():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT name FROM functions")
    rows = cursor.fetchall()
    conn.close()
    
    # 提取所有函数名称并返回
    function_names = [row['name'] for row in rows]
    return jsonify(function_names)

# 首页或默认路径（可选）
@app.route('/')
def index():
    return "<h2>函数查询 API 系统</h2><p>访问 <code>/api/functions</code> 查看函数列表。</p>"

if __name__ == '__main__':
    app.run(debug=True)
