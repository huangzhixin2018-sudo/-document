import sqlite3
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from openpyxl.utils import get_column_letter

DB_PATH = r"D:\project\function_info.db"
EXCEL_PATH = r"D:\project\function_info.xlsx"

def export_to_excel():
    conn = sqlite3.connect(DB_PATH)
    wb = Workbook()
    
    # 设置样式
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="4F81BD", end_color="4F81BD", fill_type="solid")  # 修正的填充设置
    border = Border(left=Side(style='thin'), 
                   right=Side(style='thin'), 
                   top=Side(style='thin'), 
                   bottom=Side(style='thin'))

    # 1. 导出模块表
    ws_modules = wb.create_sheet("模块", 0)
    ws_modules.append(["模块名称", "模块路径"])
    cursor = conn.cursor()
    cursor.execute("SELECT module_name, module_path FROM modules ORDER BY module_name")
    for row in cursor.fetchall():
        ws_modules.append(row)
    
    # 2. 导出函数表
    ws_functions = wb.create_sheet("函数", 1)
    headers = ["ID", "函数名", "完整限定名", "所属模块", "函数类型", "功能描述", "返回类型", "返回类型描述"]
    ws_functions.append(headers)
    cursor.execute("""
        SELECT id, function_name, qualified_name, module_name, 
               function_type, description, return_type, return_description 
        FROM functions 
        ORDER BY module_name, function_name
    """)
    for row in cursor.fetchall():
        ws_functions.append(row)
    
    # 3. 导出参数表
    ws_params = wb.create_sheet("参数", 2)
    ws_params.append(["ID", "函数完整名", "参数名", "参数类型", "是否有默认值", "默认值", "参数描述"])
    cursor.execute("""
        SELECT id, qualified_name, parameter_name, parameter_type,
               has_default, default_value, description
        FROM parameters
        ORDER BY qualified_name, parameter_name
    """)
    for row in cursor.fetchall():
        row = list(row)
        row[4] = "是" if row[4] else "否"
        row[5] = str(row[5]) if row[5] is not None else ""
        ws_params.append(row)
    
    # 4. 导出返回值表
    ws_returns = wb.create_sheet("返回值", 3)
    ws_returns.append(["ID", "函数完整名", "返回类型", "返回类型描述"])
    cursor.execute("""
        SELECT id, qualified_name, return_type, return_description 
        FROM return_values
        ORDER BY qualified_name
    """)
    for row in cursor.fetchall():
        ws_returns.append(row)
    
    # 应用样式
    for sheet in wb:
        # 设置列宽
        for col in range(1, len(sheet[1]) + 1):
            col_letter = get_column_letter(col)
            if col == 3:  # 完整限定名
                sheet.column_dimensions[col_letter].width = 40
            elif col in [6, 8]:  # 描述类字段
                sheet.column_dimensions[col_letter].width = 30
            else:
                sheet.column_dimensions[col_letter].width = 15
        
        # 设置表头样式
        for cell in sheet[1]:
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal='center', vertical='center')
            cell.border = border
        
        # 设置数据样式
        for row in sheet.iter_rows(min_row=2):
            for cell in row:
                cell.border = border
                if cell.column == 1:  # ID列居中
                    cell.alignment = Alignment(horizontal='center')
                if cell.column in [6, 7, 8]:  # 描述类字段自动换行
                    cell.alignment = Alignment(wrap_text=True)
    
    # 删除默认Sheet并保存
    if "Sheet" in wb.sheetnames:
        wb.remove(wb["Sheet"])
    
    wb.save(EXCEL_PATH)
    conn.close()
    print(f"✅ 数据已成功导出到: {EXCEL_PATH}")

if __name__ == "__main__":
    export_to_excel()