#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Python函数数据完善器
为函数查询系统和函数库系统提供更丰富的示例数据
"""

import pandas as pd
import json

class FunctionDataEnricher:
    def __init__(self):
        self.enriched_data = {}
        
    def generate_comprehensive_function_data(self):
        """生成全面的函数数据"""
        
        # 函数查询系统的丰富数据
        function_query_data = {
            'functions': [
                # 字符串操作函数
                {
                    'qualified_name': 'str.split',
                    'function_name': 'split',
                    'module_name': 'str',
                    'description': '通过指定分隔符对字符串进行分割，返回字符串列表',
                    'function_type': '方法',
                    'source_definition': 'def split(self, sep=None, maxsplit=-1): ...',
                    'return_value_description': '返回分割后的字符串列表，如果未指定分隔符则按空白字符分割'
                },
                {
                    'qualified_name': 'str.join',
                    'function_name': 'join',
                    'module_name': 'str',
                    'description': '将可迭代对象中的字符串元素用指定字符串连接',
                    'function_type': '方法',
                    'source_definition': 'def join(self, iterable): ...',
                    'return_value_description': '返回连接后的字符串'
                },
                {
                    'qualified_name': 'str.replace',
                    'function_name': 'replace',
                    'module_name': 'str',
                    'description': '将字符串中的指定子串替换为新的子串',
                    'function_type': '方法',
                    'source_definition': 'def replace(self, old, new, count=-1): ...',
                    'return_value_description': '返回替换后的新字符串'
                },
                
                # 列表操作函数
                {
                    'qualified_name': 'list.append',
                    'function_name': 'append',
                    'module_name': 'list',
                    'description': '在列表末尾添加一个元素',
                    'function_type': '方法',
                    'source_definition': 'def append(self, object): ...',
                    'return_value_description': '无返回值，直接修改原列表'
                },
                {
                    'qualified_name': 'list.extend',
                    'function_name': 'extend',
                    'module_name': 'list',
                    'description': '将可迭代对象中的所有元素添加到列表末尾',
                    'function_type': '方法',
                    'source_definition': 'def extend(self, iterable): ...',
                    'return_value_description': '无返回值，直接修改原列表'
                },
                
                # 字典操作函数
                {
                    'qualified_name': 'dict.get',
                    'function_name': 'get',
                    'module_name': 'dict',
                    'description': '获取指定键的值，如果键不存在则返回默认值',
                    'function_type': '方法',
                    'source_definition': 'def get(self, key, default=None): ...',
                    'return_value_description': '返回键对应的值，如果键不存在则返回默认值'
                },
                
                # 文件操作函数
                {
                    'qualified_name': 'open',
                    'function_name': 'open',
                    'module_name': 'builtins',
                    'description': '打开文件并返回文件对象',
                    'function_type': '函数',
                    'source_definition': 'def open(file, mode="r", buffering=-1, encoding=None, errors=None, newline=None, closefd=True, opener=None): ...',
                    'return_value_description': '返回文件对象，用于文件读写操作'
                },
                {
                    'qualified_name': 'os.path.join',
                    'function_name': 'join',
                    'module_name': 'os.path',
                    'description': '将多个路径组件智能地组合成一个完整路径',
                    'function_type': '函数',
                    'source_definition': 'def join(path, *paths): ...',
                    'return_value_description': '返回组合后的路径字符串，自动处理路径分隔符'
                },
                
                # 数学函数
                {
                    'qualified_name': 'math.sqrt',
                    'function_name': 'sqrt',
                    'module_name': 'math',
                    'description': '计算数字的平方根',
                    'function_type': '函数',
                    'source_definition': 'def sqrt(x): ...',
                    'return_value_description': '返回x的平方根，x必须是非负数'
                },
                
                # Pandas函数
                {
                    'qualified_name': 'pandas.DataFrame.head',
                    'function_name': 'head',
                    'module_name': 'pandas.DataFrame',
                    'description': '返回DataFrame的前n行数据，用于快速预览数据',
                    'function_type': '方法',
                    'source_definition': 'def head(self, n=5): ...',
                    'return_value_description': '返回包含前n行的DataFrame子集'
                },
                {
                    'qualified_name': 'pandas.read_csv',
                    'function_name': 'read_csv',
                    'module_name': 'pandas',
                    'description': '从CSV文件读取数据并创建DataFrame',
                    'function_type': '函数',
                    'source_definition': 'def read_csv(filepath_or_buffer, sep=",", delimiter=None, header="infer", names=None, index_col=None, usecols=None, squeeze=False, prefix=None, mangle_dupe_cols=True, dtype=None, engine=None, converters=None, true_values=None, false_values=None, skipinitialspace=False, skiprows=None, skipfooter=0, nrows=None, na_values=None, keep_default_na=True, na_filter=True, verbose=False, skip_blank_lines=True, parse_dates=False, infer_datetime_format=False, keep_date_col=False, date_parser=None, dayfirst=False, cache_dates=True, iterator=False, chunksize=None, compression="infer", thousands=None, decimal=".", lineterminator=None, quotechar="""", quoting=0, doublequote=True, escapechar=None, comment=None, encoding=None, dialect=None, error_bad_lines=True, warn_bad_lines=True, delim_whitespace=False, low_memory=True, memory_map=False, float_precision=None): ...',
                    'return_value_description': '返回包含CSV数据的DataFrame对象'
                }
            ],
            
            'function_parameters': [
                # str.split参数
                {
                    'function_qualified_name': 'str.split',
                    'parameter_name': 'sep',
                    'parameter_type': 'str',
                    'structure_type': '基础类型',
                    'has_default_value': True,
                    'default_value': 'None',
                    'is_required': False,
                    'description': '分隔符，默认为None表示按空白字符分割',
                    'parameter_order': 1
                },
                {
                    'function_qualified_name': 'str.split',
                    'parameter_name': 'maxsplit',
                    'parameter_type': 'int',
                    'structure_type': '基础类型',
                    'has_default_value': True,
                    'default_value': '-1',
                    'is_required': False,
                    'description': '最大分割次数，-1表示不限制',
                    'parameter_order': 2
                },
                
                # str.join参数
                {
                    'function_qualified_name': 'str.join',
                    'parameter_name': 'iterable',
                    'parameter_type': 'iterable',
                    'structure_type': '可迭代对象',
                    'has_default_value': False,
                    'default_value': '',
                    'is_required': True,
                    'description': '包含字符串元素的可迭代对象',
                    'parameter_order': 1
                },
                
                # dict.get参数
                {
                    'function_qualified_name': 'dict.get',
                    'parameter_name': 'key',
                    'parameter_type': 'object',
                    'structure_type': '基础类型',
                    'has_default_value': False,
                    'default_value': '',
                    'is_required': True,
                    'description': '要查找的键',
                    'parameter_order': 1
                },
                {
                    'function_qualified_name': 'dict.get',
                    'parameter_name': 'default',
                    'parameter_type': 'object',
                    'structure_type': '基础类型',
                    'has_default_value': True,
                    'default_value': 'None',
                    'is_required': False,
                    'description': '如果键不存在时返回的默认值',
                    'parameter_order': 2
                }
            ],
            
            'function_examples': [
                {
                    'function_qualified_name': 'str.split',
                    'example_title': '基本字符串分割',
                    'example_code': "text = 'apple,banana,orange'\nfruits = text.split(',')\nprint(fruits)",
                    'example_output': "['apple', 'banana', 'orange']",
                    'example_description': '使用逗号分割字符串，返回列表',
                    'difficulty_level': 'beginner'
                },
                {
                    'function_qualified_name': 'str.join',
                    'example_title': '列表元素连接',
                    'example_code': "words = ['Hello', 'World', 'Python']\nsentence = ' '.join(words)\nprint(sentence)",
                    'example_output': "Hello World Python",
                    'example_description': '使用空格连接列表中的字符串元素',
                    'difficulty_level': 'beginner'
                },
                {
                    'function_qualified_name': 'dict.get',
                    'example_title': '安全获取字典值',
                    'example_code': "person = {'name': 'Alice', 'age': 30}\nage = person.get('age', 0)\ncity = person.get('city', 'Unknown')\nprint(f'Age: {age}, City: {city}')",
                    'example_output': "Age: 30, City: Unknown",
                    'example_description': '使用get方法安全获取字典值，避免KeyError',
                    'difficulty_level': 'intermediate'
                },
                {
                    'function_qualified_name': 'os.path.join',
                    'example_title': '跨平台路径拼接',
                    'example_code': "import os\npath = os.path.join('home', 'user', 'documents', 'file.txt')\nprint(path)",
                    'example_output': "home/user/documents/file.txt",
                    'example_description': '使用os.path.join确保跨平台路径分隔符正确',
                    'difficulty_level': 'intermediate'
                },
                {
                    'function_qualified_name': 'pandas.read_csv',
                    'example_title': '读取CSV文件',
                    'example_code': "import pandas as pd\ndf = pd.read_csv('data.csv')\nprint(df.head())",
                    'example_output': "   Name  Age  City\n0  Alice   25  NYC\n1    Bob   30  LA\n2  Carol   35  SF",
                    'example_description': '读取CSV文件并显示前几行数据',
                    'difficulty_level': 'intermediate'
                }
            ]
        }
        
        # 函数库系统的丰富数据
        function_library_data = {
            'libraries': [
                {
                    'library_name': 'builtin',
                    'display_name': 'Python 内置库',
                    'description': 'Python标准库中的内置模块和函数，无需安装即可使用',
                    'version': '3.11'
                },
                {
                    'library_name': 'pandas',
                    'display_name': 'Pandas 库',
                    'description': '强大的数据分析和操作库，提供DataFrame和Series数据结构',
                    'version': '2.0.0'
                },
                {
                    'library_name': 'numpy',
                    'display_name': 'NumPy 库',
                    'description': '数值计算库，提供多维数组和数学函数',
                    'version': '1.24.0'
                }
            ],
            
            'operation_types': [
                {'operation_name': '构造', 'description': '创建新对象或实例', 'category': '对象操作'},
                {'operation_name': '复制', 'description': '复制现有对象', 'category': '对象操作'},
                {'operation_name': '访问', 'description': '获取对象属性或值', 'category': '数据访问'},
                {'operation_name': '查询', 'description': '查找或检索数据', 'category': '数据操作'},
                {'operation_name': '设置', 'description': '修改对象属性或值', 'category': '数据操作'},
                {'operation_name': '插入', 'description': '在数据结构中添加元素', 'category': '数据操作'},
                {'operation_name': '删除', 'description': '移除数据结构中的元素', 'category': '数据操作'},
                {'operation_name': '计算', 'description': '执行数学或逻辑运算', 'category': '计算操作'},
                {'operation_name': '转换', 'description': '将数据从一种格式转换为另一种', 'category': '数据转换'},
                {'operation_name': '聚合', 'description': '将多个值合并为单个值', 'category': '数据操作'},
                {'operation_name': '排序', 'description': '对数据进行排序', 'category': '数据操作'},
                {'operation_name': '重组', 'description': '重新组织数据结构', 'category': '数据操作'},
                {'operation_name': '判断', 'description': '返回布尔值的条件检查', 'category': '逻辑操作'},
                {'operation_name': '输入', 'description': '从外部源读取数据', 'category': 'IO操作'},
                {'operation_name': '输出', 'description': '将数据写入外部目标', 'category': 'IO操作'},
                {'operation_name': '迭代', 'description': '遍历数据结构', 'category': '控制流'},
                {'operation_name': '选择', 'description': '从数据集中选择特定元素', 'category': '数据操作'}
            ]
        }
        
        self.enriched_data = {
            'function_query': function_query_data,
            'function_library': function_library_data
        }
        
        return self.enriched_data
    
    def create_enriched_xlsx(self, filename='enriched_function_data.xlsx'):
        """创建包含丰富数据的XLSX文件"""
        
        data = self.generate_comprehensive_function_data()
        
        with pd.ExcelWriter(filename, engine='openpyxl') as writer:
            
            # 函数查询系统数据
            for table_name, table_data in data['function_query'].items():
                if table_data:  # 确保有数据
                    df = pd.DataFrame(table_data)
                    sheet_name = f'函数查询_{table_name}'[:31]
                    df.to_excel(writer, sheet_name=sheet_name, index=False)
            
            # 函数库系统数据
            for table_name, table_data in data['function_library'].items():
                if table_data:  # 确保有数据
                    df = pd.DataFrame(table_data)
                    sheet_name = f'函数库_{table_name}'[:31]
                    df.to_excel(writer, sheet_name=sheet_name, index=False)
            
            # 创建函数分类概览
            function_categories = {
                '字符串操作': ['str.split', 'str.join', 'str.replace'],
                '列表操作': ['list.append', 'list.extend'],
                '字典操作': ['dict.get'],
                '文件操作': ['open', 'os.path.join'],
                '数学函数': ['math.sqrt'],
                '数据处理': ['pandas.DataFrame.head', 'pandas.read_csv']
            }
            
            category_data = []
            for category, functions in function_categories.items():
                for func in functions:
                    category_data.append({
                        '分类': category,
                        '函数名': func,
                        '描述': '详细功能描述请参考函数详情表'
                    })
            
            category_df = pd.DataFrame(category_data)
            category_df.to_excel(writer, sheet_name='函数分类概览', index=False)
        
        print(f"丰富的函数数据已保存到 {filename}")

def main():
    """主函数"""
    enricher = FunctionDataEnricher()
    
    # 生成丰富的函数数据
    enricher.generate_comprehensive_function_data()
    
    # 创建XLSX文件
    enricher.create_enriched_xlsx()
    
    print("\n=== 数据生成完成 ===")
    print("1. enriched_function_data.xlsx - 包含丰富的函数数据")
    print("2. 数据库表结构已生成")

if __name__ == "__main__":
    main()
