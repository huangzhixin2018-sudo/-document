import sys
import os
import sqlite3
import inspect
import builtins
from types import BuiltinFunctionType, FunctionType
from typing import get_type_hints

# --- 数据库路径 ---
db_path = r"D:\编程项目\functions_metadata.db"
os.makedirs(os.path.dirname(db_path), exist_ok=True)

# --- 初始化数据库并创建表 ---
def init_db():
    conn = sqlite3.connect(db_path)
    c = conn.cursor()

    # 创建函数基本信息表
    c.execute('''
        CREATE TABLE IF NOT EXISTS function_index (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            模块路径 TEXT,
            所属类名 TEXT,
            函数名称 TEXT,
            完整调用路径 TEXT,
            函数类型 TEXT,
            返回类型 TEXT,
            返回描述 TEXT,
            文档说明 TEXT,
            源文件路径 TEXT,
            是否异步 INTEGER
        )
    ''')

    # 创建函数参数详情表
    c.execute('''
        CREATE TABLE IF NOT EXISTS function_parameters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            函数ID INTEGER,
            参数名称 TEXT,
            参数类型 TEXT,
            数据类型注解 TEXT,
            默认值 TEXT,
            是否可选 INTEGER,
            参数描述 TEXT,
            参数顺序 INTEGER,
            是否仅关键字 INTEGER,
            是否_可变参数 INTEGER,
            是否_关键字参数 INTEGER,
            FOREIGN KEY(函数ID) REFERENCES function_index(id)
        )
    ''')
    conn.commit()
    return conn

# --- 采集函数元数据 ---
def collect_functions_from_module(module, conn):
    module_name = module.__name__
    cursor = conn.cursor()

    for name in dir(module):
        try:
            obj = getattr(module, name)
            if not (inspect.isfunction(obj) or inspect.isbuiltin(obj)):
                continue

            # 基本信息
            func = obj
            mod_path = getattr(func, "__module__", module_name)
            qualname = getattr(func, "__qualname__", name)
            class_name = qualname.split('.')[0] if '.' in qualname else None
            func_name = getattr(func, "__name__", name)
            full_path = f"{mod_path}.{qualname}"
            func_type = "builtin" if isinstance(func, BuiltinFunctionType) else "function"
            is_async = int(inspect.iscoroutinefunction(func))

            # 尝试获取返回类型
            try:
                sig = inspect.signature(func)
                return_type = str(sig.return_annotation) if sig.return_annotation != inspect.Signature.empty else ""
            except Exception:
                return_type = ""

            # 文档和描述
            doc = getattr(func, "__doc__", "") or ""
            return_desc = doc.split("\n")[0] if doc else ""

            # 源文件路径
            try:
                source_path = inspect.getsourcefile(func) or ""
            except Exception:
                source_path = ""

            # 插入函数索引
            cursor.execute('''
                INSERT INTO function_index (
                    模块路径, 所属类名, 函数名称, 完整调用路径, 函数类型,
                    返回类型, 返回描述, 文档说明, 源文件路径, 是否异步
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                mod_path, class_name, func_name, full_path, func_type,
                return_type, return_desc, doc, source_path, is_async
            ))
            func_id = cursor.lastrowid

            # 采集参数信息
            try:
                sig = inspect.signature(func)
                for idx, param in enumerate(sig.parameters.values()):
                    name = param.name
                    kind = str(param.kind)
                    annotation = str(param.annotation) if param.annotation != inspect.Parameter.empty else ""
                    default = repr(param.default) if param.default != inspect.Parameter.empty else ""
                    optional = int(param.default != inspect.Parameter.empty)
                    is_kwonly = int(param.kind == param.KEYWORD_ONLY)
                    is_varargs = int(param.kind == param.VAR_POSITIONAL)
                    is_kwargs = int(param.kind == param.VAR_KEYWORD)
                    cursor.execute('''
                        INSERT INTO function_parameters (
                            函数ID, 参数名称, 参数类型, 数据类型注解, 默认值,
                            是否可选, 参数描述, 参数顺序, 是否仅关键字,
                            是否_可变参数, 是否_关键字参数
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        func_id, name, kind, annotation, default,
                        optional, "", idx, is_kwonly,
                        is_varargs, is_kwargs
                    ))
            except Exception:
                pass

        except Exception as e:
            print(f"跳过函数 {name}: {e}")

    conn.commit()

# --- 主函数 ---
def main():
    conn = init_db()
    print("开始采集 Python 内置模块函数元数据...")
    collect_functions_from_module(builtins, conn)
    print("采集完成，数据已写入：", db_path)
    conn.close()

if __name__ == "__main__":
    main()
