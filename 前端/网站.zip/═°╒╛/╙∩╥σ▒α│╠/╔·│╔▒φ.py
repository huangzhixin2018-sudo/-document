import sqlite3
import pandas as pd
from pathlib import Path

def create_chinese_function_metadata_db_and_excel(db_dir="D:/openai", db_name="函数信息表.db", excel_name="函数信息表.xlsx"):
    # 创建目录
    db_path = Path(db_dir)
    db_path.mkdir(parents=True, exist_ok=True)

    # 拼接数据库路径和 Excel 路径
    db_full_path = db_path / db_name
    excel_full_path = db_path / excel_name

    # === 一、创建 SQLite 数据库并建表 ===
    conn = sqlite3.connect(db_full_path)
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS 函数元信息 (
        编号 INTEGER PRIMARY KEY AUTOINCREMENT,
        模块名称 TEXT,
        模块路径 TEXT,
        类名称 TEXT,
        类完整名 TEXT,
        类基类 TEXT,
        类描述 TEXT,
        函数名称 TEXT,
        函数完整名称 TEXT,
        所属模块 TEXT,
        所属类 TEXT,
        函数类型 TEXT,
        装饰器 TEXT,
        函数描述 TEXT,
        源码定义 TEXT,
        是否有默认值 BOOLEAN,
        参数名称 TEXT,
        参数类型 TEXT,
        参数是否有默认值 BOOLEAN,
        参数默认值 TEXT,
        参数描述 TEXT
    );
    """)
    conn.commit()
    conn.close()

    print(f"✅ 数据库和表已创建成功：{db_full_path}")

    # === 二、生成 Excel 文件（空结构） ===
    columns = [
        "模块名称", "模块路径", "类名称", "类完整名", "类基类", "类描述",
        "函数名称", "函数完整名称", "所属模块", "所属类", "函数类型", "装饰器",
        "函数描述", "源码定义", "是否有默认值", "参数名称", "参数类型",
        "参数是否有默认值", "参数默认值", "参数描述"
    ]
    df = pd.DataFrame(columns=columns)
    df.to_excel(excel_full_path, index=False)
    print(f"✅ Excel 表结构文件已生成：{excel_full_path}")

if __name__ == "__main__":
    create_chinese_function_metadata_db_and_excel()
