import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os

# 创建目录（如果不存在）
save_dir = r'D:\编程项目'
os.makedirs(save_dir, exist_ok=True)

# 生成模拟数据条数
n = 100

# 生成数据
np.random.seed(42)
order_ids = np.arange(1001, 1001 + n)
user_ids = [f'U{str(i).zfill(3)}' for i in np.random.randint(1, 50, size=n)]
start_date = datetime(2023, 7, 1)
order_dates = [start_date + timedelta(days=int(x)) for x in np.random.randint(0, 30, size=n)]

product_ids = np.random.choice(['P100', 'P101', 'P102', 'P103', 'P104'], size=n)
product_names = {
    'P100': '手机',
    'P101': 'T恤',
    'P102': '牙膏',
    'P103': '耳机',
    'P104': '运动鞋'
}
categories = {
    'P100': '数码',
    'P101': '服饰',
    'P102': '日用',
    'P103': '数码',
    'P104': '服饰'
}
prices = {
    'P100': 2599,
    'P101': 89,
    'P102': 19,
    'P103': 399,
    'P104': 699
}

payment_methods = ['微信支付', '支付宝', '银行卡']
coupon_used = ['Y', 'N']
provinces = ['广东', '江苏', '北京', '上海', '浙江', '四川']

quantity = np.random.randint(1, 4, size=n)
payment_choices = np.random.choice(payment_methods, size=n)
coupon_choices = np.random.choice(coupon_used, size=n)
province_choices = np.random.choice(provinces, size=n)

# 组装数据
data = []
for i in range(n):
    pid = product_ids[i]
    data.append({
        'order_id': order_ids[i],
        'user_id': user_ids[i],
        'order_date': order_dates[i].strftime('%Y-%m-%d'),
        'product_id': pid,
        'product_name': product_names[pid],
        'category': categories[pid],
        'price': prices[pid],
        'quantity': quantity[i],
        'payment_method': payment_choices[i],
        'coupon_used': coupon_choices[i],
        'province': province_choices[i],
    })

df = pd.DataFrame(data)

# 保存到 Excel
file_path = os.path.join(save_dir, 'orders_data.xlsx')
df.to_excel(file_path, index=False)

print(f'文件已保存至：{file_path}')
