import sqlite3

DB_PATH = r"D:\project\function_info.db"

# 示例数据
modules = [
    {"module_name": "pandas", "module_path": "pandas.core.groupby"},
    {"module_name": "itertools", "module_path": "itertools"},
]

functions = [
    {
        "function_name": "groupby",
        "qualified_name": "pandas.core.groupby.groupby",
        "module_name": "pandas",
        "function_type": "模块函数",
        "description": "按某列对 DataFrame 分组，返回分组对象。",
        "return_type": "DataFrameGroupBy",
        "return_description": "一个分组对象，可以进行聚合等操作。"
    },
    {
        "function_name": "groupby",
        "qualified_name": "itertools.groupby",
        "module_name": "itertools",
        "function_type": "模块函数",
        "description": "对迭代器连续相同值进行分组，返回分组迭代器。",
        "return_type": "迭代器",
        "return_description": "返回 (key, group) 的迭代器。"
    },
]

parameters = [
    # pandas.groupby
    {
        "qualified_name": "pandas.core.groupby.groupby",
        "parameter_name": "by",
        "parameter_type": "str | list",
        "has_default": True,
        "default_value": "None",
        "description": "用于分组的列名或数组。"
    },
    {
        "qualified_name": "pandas.core.groupby.groupby",
        "parameter_name": "axis",
        "parameter_type": "int",
        "has_default": True,
        "default_value": "0",
        "description": "分组轴。"
    },
    # itertools.groupby
    {
        "qualified_name": "itertools.groupby",
        "parameter_name": "iterable",
        "parameter_type": "Iterable",
        "has_default": False,
        "default_value": None,
        "description": "要进行分组的可迭代对象。"
    },
    {
        "qualified_name": "itertools.groupby",
        "parameter_name": "key",
        "parameter_type": "Callable",
        "has_default": True,
        "default_value": "None",
        "description": "分组的键函数。"
    }
]

returns = [
    {
        "qualified_name": "pandas.core.groupby.groupby",
        "return_type": "DataFrameGroupBy",
        "return_description": "一个分组对象，可以进行聚合、过滤等操作。"
    },
    {
        "qualified_name": "itertools.groupby",
        "return_type": "迭代器",
        "return_description": "返回 (key, group) 的迭代器。"
    }
]

# 建表函数
def create_tables():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS modules (
            module_name TEXT PRIMARY KEY,
            module_path TEXT
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS functions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            function_name TEXT,
            qualified_name TEXT UNIQUE,
            module_name TEXT,
            function_type TEXT,
            description TEXT,
            return_type TEXT,
            return_description TEXT,
            FOREIGN KEY (module_name) REFERENCES modules(module_name)
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS parameters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            qualified_name TEXT,
            parameter_name TEXT,
            parameter_type TEXT,
            has_default INTEGER,
            default_value TEXT,
            description TEXT,
            FOREIGN KEY (qualified_name) REFERENCES functions(qualified_name)
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS return_values (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            qualified_name TEXT,
            return_type TEXT,
            return_description TEXT,
            FOREIGN KEY (qualified_name) REFERENCES functions(qualified_name)
        )
    """)

    conn.commit()
    conn.close()

# 插入数据函数
def insert_data():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    for m in modules:
        cursor.execute("INSERT OR IGNORE INTO modules (module_name, module_path) VALUES (?, ?)",
                       (m["module_name"], m["module_path"]))

    for f in functions:
        cursor.execute("""
            INSERT OR IGNORE INTO functions (
                function_name, qualified_name, module_name,
                function_type, description, return_type, return_description
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            f["function_name"], f["qualified_name"], f["module_name"],
            f["function_type"], f["description"], f["return_type"], f["return_description"]
        ))

    for p in parameters:
        cursor.execute("""
            INSERT INTO parameters (
                qualified_name, parameter_name, parameter_type,
                has_default, default_value, description
            ) VALUES (?, ?, ?, ?, ?, ?)
        """, (
            p["qualified_name"], p["parameter_name"], p["parameter_type"],
            int(p["has_default"]), p["default_value"], p["description"]
        ))

    for r in returns:
        cursor.execute("""
            INSERT INTO return_values (
                qualified_name, return_type, return_description
            ) VALUES (?, ?, ?)
        """, (r["qualified_name"], r["return_type"], r["return_description"]))

    conn.commit()
    conn.close()

# 执行主程序
if __name__ == "__main__":
    create_tables()
    insert_data()
    print("✅ 数据已成功写入 SQLite 数据库！")
